var searchData=
[
  ['assoofs_5fs_5fops',['assoofs_s_ops',['../assoofs_8c.html#a3fca1c4c2c4be95abaa61e5ad6bbf71a',1,'assoofs.c']]],
  ['assoofs_5ftype',['assoofs_type',['../assoofs_8c.html#a019931373877b6998829648548a8a83e',1,'assoofs.c']]]
];
