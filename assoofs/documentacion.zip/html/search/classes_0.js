var searchData=
[
  ['assoofs_5ffile_5fcontent',['assoofs_file_content',['../structassoofs__file__content.html',1,'']]]
];
