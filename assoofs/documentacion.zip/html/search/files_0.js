var searchData=
[
  ['assoofs_2ec',['assoofs.c',['../assoofs_8c.html',1,'']]]
];
